//& Trying to do some gateway methods 
