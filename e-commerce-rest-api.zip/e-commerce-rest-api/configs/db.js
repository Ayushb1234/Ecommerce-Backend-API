const mongoose = require('mongoose')
require('dotenv').config()

//& Function to connect to Db 

const connectWithDb = () => {

mongoose.connect(process.env.DB_URL, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  ssl: true // ✅ Ensure SSL if using Atlas
})
.then(() => console.log("✅ DB CONNECTED SUCCESSFULLY"))
.catch((error) => {
  console.log("❌ DB CONNECTION FAILED", error);
  process.exit(1);
});

}


module.exports = connectWithDb