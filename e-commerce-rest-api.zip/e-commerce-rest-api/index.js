const app = require('./app');
const connectWithDb = require('./configs/db');
require('dotenv').config()
const PORT = process.env.PORT || 5000;


connectWithDb();

app.listen( PORT , ()=>{
    console.log(`server is running on port ${PORT}` );
})